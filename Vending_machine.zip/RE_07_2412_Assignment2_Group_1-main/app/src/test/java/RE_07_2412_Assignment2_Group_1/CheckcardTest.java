package RE_07_2412_Assignment2_Group_1;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.crypto.Data;

import org.junit.jupiter.api.Test;
public class CheckcardTest {

    @Test
    void checkcardTest() throws SQLException{
        Database d = new Database();
        d.connect();
        Connection c = d.getConn();
        Card sc = new Card();
        assertTrue(sc.checkcard(d, c, "customer1")); 
        String userInput = ("cancel");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);

        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        assertFalse(sc.checkcard(d, c, "null"));

        c.close();
    }
    @Test
    void Checkcardusable() throws SQLException{
        Database d = new Database();
        d.connect();
        Connection c = d.getConn();
        Card sc = new Card();
        
        String userInput = ("asdd\n1234");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);

        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        assertTrue(sc.checkcard(d, c, "null"));
        c.close();
    }

}
