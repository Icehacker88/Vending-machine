package RE_07_2412_Assignment2_Group_1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

public class CustomerTest {


    @Test
    void buyChipsTest() throws SQLException, IOException{
        Connection conn;
        Database data = new Database();
        Customer cus = new Customer();
        data.connect();
        conn = data.getConn();
        String userInput = ("Thins\n1");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        
        assertEquals("Thins", cus.buyProduct("chips",data, conn));
        assertTrue(cus.getflag());
        conn.close();
    }

    @Test
    void buychocolatesTest() throws SQLException, IOException{
        Connection conn;
        Database data = new Database();
        Customer cus = new Customer();
        data.connect();
        conn = data.getConn();
        String userInput = ("Mars\n1");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        assertEquals("Mars", cus.buyProduct("chocolates",data, conn));
        assertTrue(cus.getflag());
        conn.close();
    }

    @Test
    void buydcandieTest() throws SQLException, IOException{
        Connection conn;
        Database data = new Database();
        Customer cus = new Customer();
        data.connect();
        conn = data.getConn();
        String userInput = ("Mentos\n1");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        assertEquals("Mentos", cus.buyProduct("candies",data, conn));
        assertTrue(cus.getflag());
        conn.close();
    }

    @Test
    void buydrinkTest() throws SQLException, IOException{
        Connection conn;
        Database data = new Database();
        Customer cus = new Customer();
        data.connect();
        conn = data.getConn();
        String userInput = ("milk\n1");
        ByteArrayInputStream bais = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(bais);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(baos);
        System.setOut(printStream);
        cus.buyProduct("drinks",data, conn);
        //assertEquals("milk", cus.buyProduct("drinks",data, conn));
        assertTrue(cus.getflag());
        conn.close();
    }
}
